# ATALHOS

**SHIFT + ALT + F ( Organizar )**

**SHIFT + ALT + SETAS** ( **Duplicar tag** )

**CTRL + Z ( DESFAZ ) 
CTRL + Y ( REFAZ )
CTRL + K + C ( atalho para tornar comentario vscode )**

**CTRL + S** ( SALVAR )

**CTRL + SHIFT + P** ( **Adicionar tag** )

**ESCREVER EXEMPLO DIV.(A CLASSE QUE QUER) Chama a TAG direto.**

**/*  - ( Comentar no CSS )**

CTRL + SHIT