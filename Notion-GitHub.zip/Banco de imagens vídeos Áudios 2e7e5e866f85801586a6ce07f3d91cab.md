# Banco de imagens/vídeos/Áudios

- **Exemplos de Áudios**
    
      [**https://www.soundhelix.com/**](https://www.soundhelix.com/)
    
- **Mapear imagem**
    
    [https://www.image-map.net/](https://www.image-map.net/)
    
- **Criar imagem**
    
    [**https://www.photopea.com**](https://www.photopea.com/)
    
- **Imagens gratuitas**
    
    [**https://www.pexels.com/pt-br**](https://www.pexels.com/pt-br/)
    
    [**https://pixabay.com/**](https://pixabay.com/)
    
    [**https://br.freepik.com/imagens**](https://br.freepik.com/imagens)
    
- **Compactar imagens**
    
    [https://www.easy-resize.com/pt/](https://www.easy-resize.com/pt/)
    
    [https://compressjpeg.com/](https://compressjpeg.com/)
    
    [https://www.iloveimg.com/compress-image/compress-jpg](https://www.iloveimg.com/compress-image/compress-jpg)
    
    [https://tinyjpg.com/](https://tinyjpg.com/)
    
- **Icones e emojis**
    
    [**https://www.flaticon.com/**](https://www.flaticon.com/)
    
    [**emojipedia.org](https://emojipedia.org/)**
    
    [https://www.iconarchive.com/](https://www.iconarchive.com/)
    
    [https://favicon.io/](https://favicon.io/)